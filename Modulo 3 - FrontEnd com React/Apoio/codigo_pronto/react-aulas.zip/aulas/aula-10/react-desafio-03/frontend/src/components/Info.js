import React from 'react';

export default function Info({ children }) {
  return <div>{children}</div>;
}
